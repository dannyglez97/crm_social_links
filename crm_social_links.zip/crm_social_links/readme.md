Estructura recomendada de commits:
text

git init
git add .
git commit -m "[ADD] Modelo res.partner con campos para redes sociales"
git commit -m "[ADD] Métodos de validación de URLs sociales"
git commit -m "[ADD] Campo computado para iconos sociales"
git commit -m "[ADD] Pruebas unitarias para funcionalidad social"
git commit -m "[FIX] Corrección en validación de dominios"